package br.ulbra.myapplication

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.math.abs
import kotlin.random.Random

class JogoActivity : AppCompatActivity() {

    private var secreto = 0
    private var tentativas = 0
    private var maximo = 100
    private var nome = "Jogador"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_jogo)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        nome = intent.getStringExtra("nome") ?: "Jogador"
        maximo = intent.getIntExtra("maximo", 100)

        // Sorteia o número totalmente aleatório entre 0 e maximo
        secreto = Random.nextInt(0, maximo + 1)

        val txtBoasVindas = findViewById<TextView>(R.id.txtBoasVindas)
        val edtPalpite = findViewById<EditText>(R.id.edtPalpite)
        val btnChutar = findViewById<Button>(R.id.btnChutar)
        val txtDica = findViewById<TextView>(R.id.txtDica)
        val txtTentativas = findViewById<TextView>(R.id.txtTentativas)
        val btnJogarDeNovo = findViewById<Button>(R.id.btnJogarDeNovo)

        txtBoasVindas.text = "$nome, pensei num número de 0 a $maximo!"

        btnChutar.setOnClickListener {
            val palpiteStr = edtPalpite.text.toString().trim()

            if (palpiteStr.isEmpty()) {
                Toast.makeText(this, "Digite o número que você quer chutar!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val palpite = palpiteStr.toIntOrNull()
            if (palpite == null) {
                Toast.makeText(this, "Digite um número válido!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            tentativas++

            if (palpite == secreto) {
                txtDica.text = "🎉 ACERTOU! O número era $secreto."
                txtTentativas.text = "$nome acertou em $tentativas tentativa(s)!"
                edtPalpite.visibility = View.GONE
                btnChutar.visibility = View.GONE
                btnJogarDeNovo.visibility = View.VISIBLE
            } else {
                val diff = abs(palpite - secreto)
                val temperatura = if (diff <= (maximo * 0.10)) "Quente!" else "Frio!"
                val direcao = if (secreto > palpite) "O número é MAIOR que $palpite." else "O número é MENOR que $palpite."

                txtDica.text = "$temperatura $direcao"
                txtTentativas.text = "Tentativas: $tentativas"

                edtPalpite.text.clear()
                edtPalpite.requestFocus()
            }
        }

        btnJogarDeNovo.setOnClickListener {
            finish()
        }
    }
}